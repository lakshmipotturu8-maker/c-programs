#include "addressbook.h"

void add_contact(struct AddressBook *addressBook)
{
    add_name(addressBook);
    add_phone(addressBook);
    add_email(addressBook);

    addressBook->contactCount ++;
}

void list_contacts(struct AddressBook *addressBook)
{
    printf("+-------+-----------------+-----------------+---------------------------+\n");
    printf("| Sl.No | Name            | Phone Number    | Email Address             |\n");
    printf("+-------+-----------------+-----------------+---------------------------+\n");

    for(int i=0;i<addressBook->contactCount;i++)
    {  
        display_name(addressBook,i);
        display_phone(addressBook,i);
        display_email(addressBook,i);
        printf("\n");
    }
    printf("\n+-------+-----------------+-----------------+---------------------------+\n\n");
    
}
void search_contact(struct AddressBook *addressBook)
{
    int choice;

    //int *ptr = arr[0];
    printf("Enter the choice:\n");
    printf("1. search by name:\n");
    printf("2. search by phone:\n");
    printf("3. search by email:\n");
    scanf("%d",&choice);

    switch(choice)
    {
        case 1:
            search_name(addressBook);
            break;
        case 2:
           search_phone(addressBook);
           break;
        case 3:
            search_email(addressBook);
            break;
        default:
            printf("Invalid choice.\n");
            break;
    }
    
}

void edit_contact(struct AddressBook *addressBook)
{
    char searchName[50];
    int choice;
    int edit;
    int real_index;

    addressBook->ir_size = 0;

    printf("\nEnter name to edit: ");
    scanf(" %[^\n]", searchName);

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].name, searchName) == 0)
        {
            addressBook->ir_size++;

            addressBook->index_record[addressBook->ir_size] = i;
        }
    }

    if (addressBook->ir_size == 0)
    {
        printf("\nContact not found!\n");
        return;
    }

    printf("\nContacts Found:\n");

    printf("+-------+-------------------+-------------------+------------------------------+\n");
    printf("| Sl.No | Name              | Phone Number      | Email Address                |\n");
    printf("+-------+-------------------+-------------------+------------------------------+\n");

    for (int i = 1; i <= addressBook->ir_size; i++)
    {
        int actual_index = addressBook->index_record[i];

        printf("| %-5d | %-17s | %-17s | %-28s |\n",
               i,
               addressBook->contacts[actual_index].name,
               addressBook->contacts[actual_index].phone,
               addressBook->contacts[actual_index].email);
    }

    printf("+-------+-------------------+-------------------+------------------------------+\n");

    if (addressBook->ir_size == 1)
    {
        choice = 1;
    }
    else
    {
        printf("\nSelect contact number to edit: ");
        scanf("%d", &choice);

        if (choice < 1 || choice > addressBook->ir_size)
        {
            printf("Invalid selection!\n");
            return;
        }
    }

    real_index = addressBook->index_record[choice];

    printf("\nSelected Contact:\n");
    printf("Name  : %s\n", addressBook->contacts[real_index].name);
    printf("Phone : %s\n", addressBook->contacts[real_index].phone);
    printf("Email : %s\n", addressBook->contacts[real_index].email);

    /* 7. Ask what to edit */
    printf("\nWhat do you want to edit?\n");
    printf("1. Name\n");
    printf("2. Phone\n");
    printf("3. Email\n");
    
    printf("Enter your choice: ");
    scanf("%d", &edit);

    switch (edit)
    {
        case 1:
            edit_name(addressBook, real_index);
            break;

        case 2:
            edit_phone(addressBook, real_index);
            break;

        case 3:
            edit_email(addressBook, real_index);
            break;

        default:
            printf("Invalid edit option!\n");
            return;
    }

    printf("\nContact edited successfully!\n");

    addressBook->ir_size = 0;
}

void delete_contact(struct AddressBook *addressBook)
{
    int choice;
    int ref;
    int index;
    char confirm;

    printf("\nDelete Contact\n");
    printf("1. Delete by name\n");
    printf("2. Delete by phone\n");
    printf("3. Delete by email\n");

    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice)
    {
        case 1:
            delete_name(addressBook);
            break;

        case 2:
            delete_phone(addressBook);
            break;

        case 3:
            delete_email(addressBook);
            break;

        default:
            printf("Invalid choice!\n");
            return;
    }
    if (addressBook->ir_size == 0)
    {
        return;
    }

    if (addressBook->ir_size > 1)
    {
        printf("Select contact number to delete: ");
        scanf("%d", &ref);

        if (ref < 1 || ref > addressBook->ir_size)
        {
            printf("Invalid selection!\n");
            return;
        }
    }
    else
    {
        ref = 1;
    }

    index = addressBook->index_record[ref];

    printf("\nSelected Contact:\n");
    printf("Name  : %s\n", addressBook->contacts[index].name);
    printf("Phone : %s\n", addressBook->contacts[index].phone);
    printf("Email : %s\n", addressBook->contacts[index].email);

    printf("\nDo you want to delete this contact? (Y/N): ");
    scanf(" %c", &confirm);

    if (confirm == 'Y' || confirm == 'y')
    {
        for (int i = index; i < addressBook->contactCount - 1; i++)
        {
            addressBook->contacts[i] = addressBook->contacts[i + 1];
        }

        addressBook->contactCount--;

        printf("Contact Deleted Successfully!\n");
    }
    else
    {
        printf("Contact deletion cancelled.\n");
    }
}
void save_contact(struct AddressBook *addressBook)
{
    FILE *fp;

    fp = fopen("database.csv", "w");

    if(fp == NULL)
    {
        printf("File Error!\n");
        return;
    }

    for(int i = 0; i < addressBook->contactCount; i++)
    {
        fprintf(fp, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fp);

    //printf("Contacts saved successfully!\n");

    //return 0;
}


void load_contact(struct AddressBook *addressBook)
{
    FILE *fp;

    fp = fopen("database.csv", "r");

    if(fp == NULL)
    {
        printf("No Previous contacts found!\n");
        return;
    }

    

    while(addressBook->contactCount < 100)
    {
        int result;

        result = fscanf(fp, "%[^,],%[^,],%[^\n]\n",
                        addressBook->contacts[addressBook->contactCount].name,
                        addressBook->contacts[addressBook->contactCount].phone,
                        addressBook->contacts[addressBook->contactCount].email);

        if(result == 3)
        {

            (addressBook->contactCount)++;
        }
        else
        {
            break;
        }
    }

    fclose(fp);

    printf("Contacts Loaded Successfully!\n");
}