#include"addressbook.h"
#include<string.h>
void add_name(struct AddressBook * a)
{
    //NAME   
    printf("Enter the contact name: ");
    scanf(" %[^\n]", a->contacts[a->contactCount].name);

    
}

void add_phone(struct AddressBook *a)
{
    char temp[15];
    int i;
    int valid;

    while(1)
    {
        printf("Enter the phone number: ");
        scanf("%s", temp);

        valid = 1;

        // 1. Length must be 10
        if(strlen(temp) != 10)
        {
            valid = 0;
        }

        // 2. All characters must be digits
        for(i = 0; temp[i] != '\0'; i++)
        {
            if(temp[i] < '0' || temp[i] > '9')
            {
                valid = 0;
                break;
            }
        }

        // 3. First digit must be 6 to 9
        if(temp[0] != '6' && temp[0] != '7' &&
           temp[0] != '8' && temp[0] != '9')
        {
            valid = 0;
        }

        // Invalid phone
        if(valid == 0)
        {
            printf("Invalid phone number. Please enter again.\n");
            continue;
        }

        // 4. Check unique phone number
        for(i = 0; i < a->contactCount; i++)
        {
            if(strcmp(temp, a->contacts[i].phone) == 0)
            {
                printf("Phone number already exists.\n");
                valid = 0;
                break;
            }
        }

        if(valid == 1)
        {
            break;
        }
    }

    strcpy(a->contacts[a->contactCount].phone, temp);
}

void add_email(struct AddressBook *a)
{
    char temp[50];
    int i;
    int valid;

    while(1)
    {
        printf("Enter the email: ");
        scanf("%s", temp);

        valid = 1;

        // First character should not be @ or .
        if(temp[0] == '@' || temp[0] == '.')
        {
            valid = 0;
        }

        // Check @
        if(strchr(temp, '@') == NULL)
        {
            valid = 0;
        }

        // .com should be at the end
        if(strlen(temp) < 4 ||
           strcmp(temp + strlen(temp) - 4, ".com") != 0)
        {
            valid = 0;
        }

        // Convert uppercase letters to lowercase
        for(i = 0; temp[i] != '\0'; i++)
        {
            if(temp[i] >= 'A' && temp[i] <= 'Z')
            {
                temp[i] = temp[i] + 32;
            }
        }

        if(valid == 0)
        {
            printf("Invalid email. Please enter again.\n");
            continue;
        }

        // Email should be unique
        for(i = 0; i < a->contactCount; i++)
        {
            if(strcmp(temp, a->contacts[i].email) == 0)
            {
                printf("Email already exists.\n");
                valid = 0;
                break;
            }
        }

        if(valid == 1)
        {
            break;
        }
    }

    // Store email
    strcpy(a->contacts[a->contactCount].email, temp);
}