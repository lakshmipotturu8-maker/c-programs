#include"addressbook.h"
#include<string.h>

void display_name(struct AddressBook *addressBook,int i)

{
    printf("%d \t %s\t ",i+1,addressBook->contacts[i].name);
}
void display_phone(struct AddressBook *addressBook,int i)
{
    printf("%s \t",addressBook->contacts[i].phone);
}
void display_email(struct AddressBook *addressBook,int i)
{
    printf("%s \t",addressBook->contacts[i].email);
}
