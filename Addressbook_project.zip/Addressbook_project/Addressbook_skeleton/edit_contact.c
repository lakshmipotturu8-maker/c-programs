#include "addressbook.h"
#include <stdio.h>
#include <string.h>

void edit_name(struct AddressBook *addressBook, int index)
{
    char newName[50];

    printf("Enter new name: ");
    scanf(" %[^\n]", newName);

    strcpy(addressBook->contacts[index].name, newName);
    printf("Name updated successfully!\n");
}
void edit_phone(struct AddressBook *addressBook, int index)
{
    char newPhone[15];

    printf("Enter new phone: ");
    scanf("%14s", newPhone);

    strcpy(addressBook->contacts[index].phone, newPhone);
    printf("Phone updated successfully!\n");
}

void edit_email(struct AddressBook *addressBook, int index)
{
    char newEmail[50];

    printf("Enter new email: ");
    scanf("%49s", newEmail);

    strcpy(addressBook->contacts[index].email, newEmail);
    printf("Email updated successfully!\n");
}