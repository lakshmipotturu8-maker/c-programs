#include "addressbook.h"
#include <stdio.h>
#include <string.h>

void search_name(struct AddressBook *addressBook)
{

    char searchName[50];
    int found=0;
    int count = 1;
    //int arr[100];
    //read from the user
    printf("enter the name: ");
    scanf("%s",searchName);

    
          printf("+-------+-------------------+-------------------+------------------------------+\n");
          printf("| Sl.No | Name              | Phone Number      | Email Address                |\n");
          printf("+-------+-------------------+-------------------+------------------------------+\n");//loop through the addressbook contacts
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if (strcmp(addressBook->contacts[i].name, searchName) == 0)
        {
            addressBook->index_record[count] = i;
            printf("%d\t",count);
            printf("%s\t", addressBook->contacts[i].name);
            printf("%s\t", addressBook->contacts[i].phone);
            printf("%s\t\n", addressBook->contacts[i].email);
            found = 1;
            count++;
            printf("\n");      
        }
    }
    printf("+-------+-------------------+-------------------+------------------------------+\n");
    if(!found)
    {
        printf("contact not found!\n");
    }
}

void search_phone(struct AddressBook *addressBook)
{
    char searchPhone[20];
    int found = 0;
    int count = 1;
   // int arr[100];

    // Read phone number from user
    printf("Enter Phone Number: ");
    scanf("%s", searchPhone);

    // Loop through addressbook contacts
    printf("+-------+-------------------+-------------------+------------------------------+\n");
          printf("| Sl.No | Name              | Phone Number      | Email Address                |\n");
          printf("+-------+-------------------+-------------------+------------------------------+\n");//loop through the addressbook contacts
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if (strcmp(addressBook->contacts[i].phone, searchPhone) == 0)
        {
            addressBook->index_record[count] = i;
            printf("%d\t",count);
            printf("%s\t", addressBook->contacts[i].name);
            printf("%s\t", addressBook->contacts[i].phone);
            printf("%s\t\n", addressBook->contacts[i].email);
            found = 1;
            count++;
            printf("\n");      
        }
    }
    printf("+-------+-------------------+-------------------+------------------------------+\n");
    if(!found)
    {
        printf("contact not found!\n");
    }
    

}
void search_email(struct AddressBook *addressBook)
{
    char searchEmail[50];
    int found = 0;
    int count = 1;

    // Read email address from user6
    printf("Enter Email Address: ");
    scanf("%s", searchEmail);

    // Loop through addressbook contacts
    printf("+-------+-------------------+-------------------+------------------------------+\n");
          printf("| Sl.No | Name              | Phone Number      | Email Address                |\n");
          printf("+-------+-------------------+-------------------+------------------------------+\n");//loop through the addressbook contacts
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if (strcmp(addressBook->contacts[i].email, searchEmail) == 0)
        {

            // Same
            addressBook->index_record[count] = i;
            printf("%d\t",count);
            printf("%s\t", addressBook->contacts[i].name);
            printf("%s\t", addressBook->contacts[i].phone);
            printf("%s\t\n", addressBook->contacts[i].email);
            found = 1;
            count++;
            printf("\n");
        } 
        printf("+-------+-------------------+-------------------+------------------------------+");
    }
    // Else -> Print contact not found
    if (found ==0)
    {
        printf("Contact not found!\n\n");
    }
    
}