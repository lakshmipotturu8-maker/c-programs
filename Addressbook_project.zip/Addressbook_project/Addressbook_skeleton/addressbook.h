#ifndef CONTACT_H
#define CONTACT_H
#include<stdio.h>
#include<string.h>




struct Contact{
    char name[50];
    char phone[15];
    char email[50];
};

struct AddressBook {
    struct Contact contacts[100];
    int contactCount;
    int index_record[100];
    int ir_size;
};

void add_contact(struct AddressBook *addressBook);
void search_contact(struct AddressBook *addressBook);
void edit_contact(struct AddressBook *addressBook);
void delete_contact(struct AddressBook *addressBook);
void list_contacts(struct AddressBook *addressBook);
/* Add Contact functions */
void add_name(struct AddressBook *a);
void add_phone(struct AddressBook *a);
void add_email(struct AddressBook *a);

void display_name(struct AddressBook *addressBook,int i);
void display_phone(struct AddressBook *addressBook,int i);
void display_email(struct AddressBook *addressBook,int i);

void search_name(struct AddressBook *addressBook);
void search_phone(struct AddressBook *addressBook);
void search_email(struct AddressBook *addressBook);
 

void edit_name(struct AddressBook *addressBook, int index);
void edit_phone(struct AddressBook *addressBook, int index);
void edit_email(struct AddressBook *addressBook, int index);

void delete_name(struct AddressBook *addressBook);
void delete_phone(struct AddressBook *addressBook);
void delete_email(struct AddressBook *addressBook);


void save_contact(struct AddressBook *addressBook);
void load_contact(struct AddressBook *addressBook);

#endif
