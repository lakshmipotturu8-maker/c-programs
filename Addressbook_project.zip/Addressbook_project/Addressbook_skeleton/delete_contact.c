#include "addressbook.h"
#include <stdio.h>
#include <string.h>

void delete_name(struct AddressBook *addressBook)
{
    char searchName[50];
    int count = 1;

    printf("Enter name: ");
    scanf(" %[^\n]", searchName); 

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].name, searchName) == 0)
        {
            addressBook->index_record[count] = i;

            printf("%d) %s | %s | %s\n",
                   count,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);

            count++;
        }
    }

    addressBook->ir_size = count - 1;

    if (addressBook->ir_size == 0)
    {
        printf("Contact not found!\n");
    }
}

void delete_phone(struct AddressBook *addressBook)
{
    char searchPhone[20];
    int count = 1;

    printf("Enter phone number: ");
    scanf("%19s", searchPhone);

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].phone, searchPhone) == 0)
        {
            addressBook->index_record[count] = i;

            printf("%d) %s | %s | %s\n",
                   count,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);

            count++;
        }
    }

    addressBook->ir_size = count - 1;

    if (addressBook->ir_size == 0)
    {
        printf("Contact not found!\n");
    }
}
void delete_email(struct AddressBook *addressBook)
{
    char searchEmail[50];
    int count = 1;

    printf("Enter email: ");
    scanf("%49s", searchEmail);

    for (int i = 0; i < addressBook->contactCount; i++)
    {
        if (strcmp(addressBook->contacts[i].email, searchEmail) == 0)
        {
            addressBook->index_record[count] = i;

            printf("%d) %s | %s | %s\n",
                   count,
                   addressBook->contacts[i].name,
                   addressBook->contacts[i].phone,
                   addressBook->contacts[i].email);

            count++;
        }
    }

    addressBook->ir_size = count - 1;

    if (addressBook->ir_size == 0)
    {
        printf("Contact not found!\n");
    }
}